# Где менять внешний вид

Все пути ниже относятся к `game_files/src/Client.Godot/`, если не указано иначе.

| Объект | Источник оформления | Что учитывать |
|---|---|---|
| Игрок/NPC | WorldModels.cs → Person; PresentationStage.cs → Show/Target | Цвет по ID, текст отдельно, движение интерполируется |
| Клетки/участки/преграды/дорога | PresentationStage.cs → RebuildStatic | Оттенок земли зависит от координат, горизонталь дороги — от соседей |
| Ресурсная клетка | WorldModels.cs → Resource/DepletedResource | wood, grain, milk, beet; активное и истощённое состояние |
| Производства | WorldModels.cs → Building/Sawmill/Bakery/FoodFactory | L1/L2; названия и реальные рецепты не менять ради оформления |
| Склад/ограждение | WorldModels.Warehouse.cs → Warehouse | Параметрическая форма по Footprint/Walls, anchor — проход погрузки |
| Запас склада | WorldModels.Warehouse.cs → WarehouseStock | Товары/слоты/слои; раскладка — reference/src/Simulation.Hosting/WarehouseVisuals.cs |
| Лавка/столица | WorldModels.cs → BaseBuilding | Фиолетовый акцент лавки, торговые данные отдельно |
| Техника/рейс | WorldModels.cs → Equipment/Truck; PresentationStage.cs | Два уровня добывающей техники, рейсы loaded/empty |
| 2D Debug-карта и легенда | MapSymbols.cs; DebugBoard.cs | Символы рисуются Draw*, PNG-копии в previews/rendered — справочные |
| Значки ресурсов HUD | ResourceIcon.cs; ResourceInventoryHud.cs | Draw*; только физический запас рюкзака, размер не зависит от emoji |
| Общий HUD/меню | PresentationTheme.cs; Playfield.Interface.cs; Playfield.cs; Playfield.Feedback.cs | Scoped TabletDesign не перекрашивает HUD/Developer |
| Лесопилка | delsk_sawmill_ui/; ProductionTabletPresenter.cs | Текущая сцена/иконки, реальные кнопки; compact fallback |
| Пекарня | delsk_bakery_ui/; ProductionTabletPresenter.cs | Шрифты берутся из папки лесопилки |
| Остальные производства | tablets_v1/screens/; tablets_v1/assets/; ProductionTabletPresenter.cs | Общие theme.tres/иконки; нестандартный рецепт → generic карточка |
| Generic карточки/маршруты | HouseholdObjectCard.cs; RouteEditor.cs; QuantityInput.cs | Не терять доступ/handlers и независимость процессов |
| Биржа/рынок/сделки | ExchangeTablet.cs; CapitalTablet.cs; ParticipantMarketTablet.cs; CurrentDealsPanel.cs; TradeNegotiationPanel.cs; PurchaseGuidePanel.cs | Реальные страницы и формы строятся программно |
| Игрок/голосование | PlayerTablet.cs; VotingPanel.cs; Playfield.Elections.cs | Только собственные/двусторонние приватные данные |
| Справка/планшет | HelpOverlay.cs; TabletPanel.cs; Playfield.Tablets.cs | Help/Close/Time сохраняют общую паузу |
| Общая светлая тема планшетов | TabletDesign.cs; tablets_v1/theme.tres | Art(key) содержит aliases wood/logs, plank/boards, shop/market |
| Debug/God UI | Developer/DeveloperPanel.cs; Developer/Playfield.Developer.cs | Только Developer debug export; не переносить в Release |
| Реплики/эффекты | PresentationStage.cs → ShowSpeech; Playfield.Feedback.cs; reference/src/Simulation.Hosting/PresentationEffects.cs | Текст публичных событий, косметика без World PRNG |
| Шрифты | delsk_sawmill_ui/assets/fonts/ | 3 файла Nunito + OFL; Godot fallback отдельно в движке |
| Иконка приложения | icon.svg | project.godot: config/icon |

`reference/` содержит окружение и проекцию данных для чтения. Это не overlay для
автоматического возврата в проект. `tools/` содержит только изолированный инструмент
получения этого пакета, его также не нужно копировать в обычный клиент.
