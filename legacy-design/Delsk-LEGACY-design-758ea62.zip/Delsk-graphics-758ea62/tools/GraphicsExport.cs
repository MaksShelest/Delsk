using Godot;
using Simulation.Core;
using Simulation.Hosting;
using System.Text.Json;

// Isolated asset handoff tool. It never enters the game project.
public partial class GraphicsExport : Node
{
    private string _output = "";
    private readonly List<object> _index = [];
    private Node3D _gallery = new() { Name = "DelskGraphicsGallery" };
    public override void _Ready()
    {
        try
        {
            var args = OS.GetCmdlineUserArgs();
            _output = args[Array.IndexOf(args, "--output") + 1];
            Directory.CreateDirectory(_output);
            foreach (var item in new[] { "wood", "grain", "milk", "beet" })
            {
                Save("resource-" + item, WorldModels.Resource(item), "WorldModels.Resource");
                Save("resource-depleted-" + item, WorldModels.DepletedResource(item), "WorldModels.DepletedResource");
            }
            foreach (var type in new[] { "sawmill", "bakery", "dairy", "sugar-factory", "confectionery" })
                foreach (int level in new[] { 1, 2 }) Save(type + "-L" + level, WorldModels.Building("production", type, level), "WorldModels.Building");
            Save("shop", WorldModels.Building("shop", "shop"), "WorldModels.Building");
            Save("capital", WorldModels.Building("capital", ""), "WorldModels.Building");
            foreach (var (name, color) in new[] { ("human", "eef0dc"), ("npc-2", "d87667"), ("npc-3", "6699cf"), ("npc-4-and-fallback", "e7ae58") })
                Save(name, WorldModels.Person(new Color(color), ""), "WorldModels.Person / PresentationStage.Show");
            Save("truck-empty", WorldModels.Truck(false), "WorldModels.Truck");
            Save("truck-loaded", WorldModels.Truck(true), "WorldModels.Truck");
            // Only wood/grain equipment exists in the current game catalog.
            foreach (var item in new[] { "wood", "grain" })
                foreach (int level in new[] { 1, 2 }) Save("equipment-" + item + "-L" + level, WorldModels.Equipment(item, level), "WorldModels.Equipment");
            var yard = new PresentationMarker("warehouse", 0, 0, "warehouse", 1, 1)
                { Footprint = [new(0, 0), new(1, 0)], Walls = [new(1, 0)], Warehouse = new(true, 200, []) };
            Save("warehouse-example-two-cells", WorldModels.Warehouse(yard), "WorldModels.Warehouse; parameterized footprint example");
            Save("warehouse-example-single-cell", WorldModels.Warehouse(yard with { Footprint = [new(0, 0)], Walls = [] }), "WorldModels.Warehouse; parameterized footprint example");
            foreach (string item in new[] { "wood", "grain", "plank", "bread", "milk", "beet", "cheese", "sugar", "pastry" })
                foreach (int layers in new[] { 1, 4 }) Save("stock-" + item + "-layers-" + layers, WorldModels.WarehouseStock(yard, [new(item, 0, layers)]), "WorldModels.WarehouseStock; slot 0 example");
            foreach (string kind in new[] { "blocked", "shop-plot", "plot-own", "plot-foreign", "plot-reserved", "plot-free", "corridor" })
                Save("tile-" + kind, StageModel([new(kind, 0, 0, "", 0, 0)], 1), "PresentationStage.RebuildStatic");
            Save("tile-corridor-horizontal", StageModel([new("corridor", 0, 0, "", 0, 0), new("corridor", 1, 0, "", 0, 0)], 1), "PresentationStage.RebuildStatic");
            var ground = StageModel([], 0);
            Save("ground-patch-with-nine-shades", ground, "PresentationStage.RebuildStatic; 9x1 sample");
            var selection = new MeshInstance3D { Mesh = new BoxMesh { Size = new(.96f, .025f, .96f) }, MaterialOverride = new StandardMaterial3D { AlbedoColor = new("f2cd6a"), ShadingMode = BaseMaterial3D.ShadingModeEnum.Unshaded } };
            var selectionRoot = new Node3D(); selectionRoot.AddChild(selection);
            Save("selection", selectionRoot, "PresentationStage._Ready");
            var camera = new Camera3D { Position = new(11, 34, 28), Current = true, Fov = 50 };
            _gallery.AddChild(camera); camera.LookAtFromPosition(camera.Position, new(11, 0, 12), Vector3.Up);
            _gallery.AddChild(new WorldEnvironment { Environment = new Godot.Environment { BackgroundMode = Godot.Environment.BGMode.Color, BackgroundColor = new("96aeb2") } });
            Own(_gallery, _gallery);
            var galleryScene = new PackedScene(); Require(galleryScene.Pack(_gallery), "pack gallery");
            Require(ResourceSaver.Save(galleryScene, Path.Combine(_output, "Gallery.tscn")), "save gallery");
            File.WriteAllText(Path.Combine(_output, "models.json"), JsonSerializer.Serialize(_index, new JsonSerializerOptions { WriteIndented = true }));
            GD.Print("DELSK_GRAPHICS_EXPORT_PASS models=" + _index.Count);
            _gallery.Free(); GetTree().Quit();
        }
        catch (Exception error) { GD.PushError(error.ToString()); GetTree().Quit(1); }
    }
    private Node3D StageModel(PresentationMarker[] markers, int index)
    {
        var stage = new PresentationStage(); AddChild(stage);
        stage.Show(new(0, 9, 1, [], markers, []), true, 0, "", false);
        var model = stage.GetChildren().OfType<Node3D>().Where(n => n is not Camera3D && n is not MeshInstance3D).ElementAt(index);
        stage.RemoveChild(model); stage.Free(); return model;
    }
    private static IEnumerable<Node> All(Node n)
    { yield return n; foreach (Node child in n.GetChildren()) foreach (var item in All(child)) yield return item; }
    private static void Own(Node node, Node root)
    { foreach (Node child in node.GetChildren()) { child.Owner = root; Own(child, root); } }
    private static void Require(Error error, string action)
    { if (error != Error.Ok) throw new InvalidOperationException(action + ": " + error); }
    private void Save(string name, Node3D model, string source)
    {
        model.Name = name; model.Position = Vector3.Zero;
        // Dynamic captions are renderer-generated UI, not geometry. Sources retain their settings.
        foreach (var label in All(model).OfType<Label3D>().ToArray()) { label.GetParent().RemoveChild(label); label.Free(); }
        Own(model, model);
        int meshCount = All(model).OfType<MeshInstance3D>().Count();
        if (meshCount == 0) throw new Exception("Empty model " + name);
        var scene = new PackedScene(); Require(scene.Pack(model), "pack " + name);
        string scenePath = Path.Combine(_output, name + ".tscn"); Require(ResourceSaver.Save(scene, scenePath), "save scene " + name);
        var document = new GltfDocument(); var state = new GltfState();
        Require(document.AppendFromScene(model, state), "append " + name);
        string glbPath = Path.Combine(_output, name + ".glb"); Require(document.WriteToFilesystem(state, glbPath), "write glb " + name);
        var reloadedState = new GltfState(); Require(document.AppendFromFile(glbPath, reloadedState), "reload glb " + name);
        var reloaded = document.GenerateScene(reloadedState);
        if (reloaded is null || All(reloaded).OfType<MeshInstance3D>().Count() != meshCount) throw new Exception("GLB mesh mismatch " + name);
        reloaded.Free();
        var native = GD.Load<PackedScene>(scenePath).Instantiate();
        if (All(native).OfType<MeshInstance3D>().Count() != meshCount) throw new Exception("TSCN mesh mismatch " + name);
        native.Free();
        _index.Add(new { name, source, meshCount, glb = name + ".glb", nativeScene = name + ".tscn", verifiedRoundTrip = true });
        // Keep the ground patch from covering adjacent gallery objects.
        var holder = new Node3D { Name = "item_" + _index.Count, Position = new((_index.Count - 1) % 8 * 3, 0, (_index.Count - 1) / 8 * 3) };
        _gallery.AddChild(holder); holder.AddChild(model);
        if (name.StartsWith("ground-")) model.Scale = new(.2f, 1, .8f);
        holder.AddChild(new Label3D { Text = name, Position = new(0, 1.6f, 0), FontSize = 26, PixelSize = .006f, Billboard = BaseMaterial3D.BillboardModeEnum.Enabled });
    }
}
