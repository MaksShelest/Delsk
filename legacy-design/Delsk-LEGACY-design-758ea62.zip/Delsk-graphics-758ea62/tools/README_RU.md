# Инструмент выгрузки

GraphicsExport.cs и GraphicsCapture.cs — изолированные C#-классы, использованные
при получении этого пакета, для справки. Это не мод игры и не готовый самостоятельный
проект. Не копируйте их в Client.Godot.

Для повторения в полном репозитории потребуется отдельный Godot .NET 4.7.2-проект
с net10.0/ImplicitUsings/Nullable, копиями WorldModels.cs, WorldModels.Warehouse.cs,
PresentationStage.cs, MapSymbols.cs, DebugBoard.cs и ResourceIcon.cs из выбранного HEAD
и references на собранные Simulation.Core/Simulation.Hosting.
У корневой сцены Node укажите скрипт GraphicsExport.cs; передайте после `--` аргументы
`--output <каталог моделей>`. Для PNG запустите отдельную сцену со скриптом
GraphicsCapture.cs в оконном renderer (например Xvfb/Mesa), с `--output <каталог captures>`;
рядом с captures ожидается models/Gallery.tscn.

Исходные файлы рендера находятся в game_files, типы проекции — в reference.
Готовая галерея project.godot в корне пакета работает без этого инструмента.
