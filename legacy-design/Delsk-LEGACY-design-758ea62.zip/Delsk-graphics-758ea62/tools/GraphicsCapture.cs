using Godot;
using Simulation.Hosting;

public partial class GraphicsCapture : Node
{
    private SubViewport _viewport = null!;
    private string _output = "";
    public override async void _Ready()
    {
        try
        {
            var args = OS.GetCmdlineUserArgs(); _output = args[Array.IndexOf(args, "--output") + 1];
            Directory.CreateDirectory(_output);
            _viewport = new SubViewport { Size = new(32, 32), TransparentBg = true, RenderTargetUpdateMode = SubViewport.UpdateMode.Always, OwnWorld3D = true }; AddChild(_viewport);
            foreach (string item in new[] { "wood", "grain", "plank", "bread", "milk", "beet", "cheese", "sugar", "pastry" })
                await Capture("hud-" + item, new ResourceIcon { Item = item, Size = new(32, 32) }, new(32, 32));
            foreach (var kind in new[] { "blocked", "corridor", "plot-free", "plot-own", "plot-foreign", "plot-reserved", "shop-plot", "production", "warehouse", "shop", "equipment", "truck-home", "capital", "cargo" })
                await Capture("debug-" + kind, new LegendIcon { Kind = kind }, new(36, 32));
            foreach (string item in new[] { "wood", "grain", "milk", "beet" })
            {
                await Capture("debug-resource-" + item, new LegendIcon { Kind = "resource", Item = item }, new(36, 32));
                await Capture("debug-depleted-" + item, new LegendIcon { Kind = "resource-depleted", Item = item }, new(36, 32));
            }
            foreach (string id in new[] { "1", "2", "3", "4" })
                await Capture("debug-actor-" + id, new LegendIcon { Kind = id == "1" ? "player" : "npc", Item = id }, new(36, 32));
            _viewport.Size = new(1600, 1200); _viewport.TransparentBg = false;
            var gallery = GD.Load<PackedScene>(Path.Combine(_output, "../models/Gallery.tscn")).Instantiate();
            _viewport.AddChild(gallery);
            await Frames();
            Save("models-gallery");
            gallery.Free();
            GD.Print("DELSK_GRAPHICS_CAPTURE_PASS"); GetTree().Quit();
        }
        catch (Exception error) { GD.PushError(error.ToString()); GetTree().Quit(1); }
    }
    private async Task Frames()
    {
        for (int i = 0; i < 2; i++) await ToSignal(GetTree(), SceneTree.SignalName.ProcessFrame);
        await ToSignal(RenderingServer.Singleton, RenderingServer.SignalName.FramePostDraw);
    }
    private async Task Capture(string name, Control control, Vector2I size)
    { _viewport.Size = size; _viewport.AddChild(control); await Frames(); Save(name); _viewport.RemoveChild(control); control.Free(); }
    private void Save(string name)
    {
        var image = _viewport.GetTexture().GetImage();
        if (image.IsEmpty() || image.SavePng(Path.Combine(_output, name + ".png")) != Error.Ok) throw new Exception("Capture failed " + name);
    }
}
