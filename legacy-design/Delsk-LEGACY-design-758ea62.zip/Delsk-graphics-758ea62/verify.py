# Verify archive payload after extraction. Python 3, standard library only.
from pathlib import Path
import hashlib
root = Path(__file__).resolve().parent
count = 0
for line in (root / 'SHA256SUMS.txt').read_text(encoding='utf-8').splitlines():
    expected, relative = line.split('  ', 1)
    path = root / relative
    if path.is_symlink() or not path.is_file():
        raise SystemExit('Missing or unexpected file: ' + relative)
    if hashlib.sha256(path.read_bytes()).hexdigest() != expected:
        raise SystemExit('Changed: ' + relative)
    count += 1
print('OK:', count, 'files match the original package')
