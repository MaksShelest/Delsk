extends Node
## Visual fixture only. Simulation.Core remains authoritative in the real game.
signal ui_action(action: StringName, payload: Dictionary)
var current: Control
var current_key := "catalog"
var history: Array[String] = []
var wage_minor := 20
var truck_wage_minor := 20
var running := false
var producing := true
var overlay: Control
var last_notice := ""

func _ready() -> void:
	var capture := ""
	var view := "catalog"
	var capture_all := ""
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--view="): view = arg.trim_prefix("--view=")
		if arg.begins_with("--capture="): capture = arg.trim_prefix("--capture=")
		if arg.begins_with("--capture-all="): capture_all = arg.trim_prefix("--capture-all=")
	open_screen(view, false)
	if not capture_all.is_empty():
		var manifest = JSON.parse_string(FileAccess.get_file_as_string("res://manifest.json"))
		for item in manifest:
			open_screen(item.key, false)
			for frame in range(4): await get_tree().process_frame
			await RenderingServer.frame_post_draw
			var err := get_viewport().get_texture().get_image().save_png(capture_all.path_join(item.key+".png"))
			if err != OK: get_tree().quit(err); return
			print("CAPTURE_RESULT=0 ", item.key)
		get_tree().quit()
		return
	if not capture.is_empty():
		for frame in range(5): await get_tree().process_frame
		await RenderingServer.frame_post_draw
		var err := get_viewport().get_texture().get_image().save_png(capture)
		print("CAPTURE_RESULT=", err, " ", view)
		get_tree().quit(err)

func open_screen(key: String, remember: bool = true) -> void:
	if not ResourceLoader.exists("res://screens/" + key + ".tscn"): return
	if remember: history.append(current_key)
	if is_instance_valid(overlay): overlay.free()
	if is_instance_valid(current): current.free()
	current_key = key
	current = load("res://screens/" + key + ".tscn").instantiate()
	add_child(current)
	connect_controls(current)
	refresh_state()
	refresh_trade_fields()

func connect_controls(node: Node) -> void:
	if node is OptionButton and node.name == "TradeKind":
		node.item_selected.connect(func(_i: int): refresh_trade_fields())
	elif node is CheckButton:
		node.toggled.connect(func(on: bool): ui_action.emit(StringName(node.name), {"enabled": on}))
	elif node is Button and not node is OptionButton:
		var target: String = node.get_meta("target", "")
		var action: String = node.get_meta("action", "")
		if not target.is_empty(): node.pressed.connect(open_screen.bind(target))
		elif not action.is_empty(): node.pressed.connect(act.bind(action))
	for child in node.get_children(): connect_controls(child)

func find_named(node: Node, name_: String) -> Node:
	if node.name == name_: return node
	for child in node.get_children():
		var found := find_named(child, name_)
		if found != null: return found
	return null

func refresh_state() -> void:
	var l = find_named(current, "WageAmount")
	if l != null: l.text = ("%.2f" % (wage_minor/100.0)).replace(".", ",")
	l = find_named(current, "TruckWage")
	if l != null: l.text = ("%.2f" % (truck_wage_minor/100.0)).replace(".", ",")
	l = find_named(current, "ProductionToggle")
	if l == null: l = find_named(current, "PauseProduction")
	if l != null: l.text = "Приостановить" if producing else "Запустить"
	l = find_named(current, "ProductionStatus")
	if l != null: l.text = "●  Работает" if producing else "Остановлено"
	if current.has_node("Panel/StatusPill/Text"):
		current.get_node("Panel/StatusPill/Text").text = "Работает" if producing else "Остановлено"
	l = find_named(current, "PauseState")
	if l != null: l.text = "Время идёт" if running else "Время остановлено"
	l = find_named(current, "TimeToggle")
	if l != null: l.text = "Остановить время" if running else "Продолжить время"

func refresh_trade_fields() -> void:
	var kind = find_named(current, "TradeKind")
	if kind == null: return
	find_named(current,"TradeSource").disabled = kind.selected != 0
	find_named(current,"TradeDestination").disabled = kind.selected == 0 or kind.selected == 3
	find_named(current,"TradePrice").editable = kind.selected != 3
	find_named(current,"TradeDuration").editable = kind.selected != 3
	find_named(current,"OfferOwnSupport").disabled = kind.selected != 3

func act(action: String) -> void:
	if action == "back":
		open_screen(history.pop_back() if not history.is_empty() else "catalog", false)
		return
	if action == "time": running = not running
	elif action == "production": producing = not producing
	elif action == "wage_plus": wage_minor += 5
	elif action == "wage_minus": wage_minor = maxi(0, wage_minor-5)
	elif action == "truck_wage_plus": truck_wage_minor += 5
	elif action == "truck_wage_minus": truck_wage_minor = maxi(0, truck_wage_minor-5)
	elif action.begins_with("help_full_"):
		var data = JSON.parse_string(FileAccess.get_file_as_string("res://help_texts.json"))
		show_notice("Полные правила", data.get(action.trim_prefix("help_full_"), "Двигайтесь с помощью WASD. Нажимайте кнопки мышью или подтверждайте действие Enter. Планшеты открываются с паузой. Команды исполняются после возобновления времени."))
	else:
		var labels := {
			"collect": "Получить выбранное количество", "collect_all": "Получить всё по вместимости",
			"bid_submit": "Подать заявку на покупку", "bid_raise": "Повысить ставку", "bid_withdraw": "Отозвать заявку",
			"propose": "Отправить предложение", "accept_v2": "Принять версию 2", "reject_v2": "Отказаться от версии",
			"walk": "Подойти к выбранному объекту", "publish": "Опубликовать лот", "create_buy": "Опубликовать закупку",
			"route_save": "Сохранить маршрут", "route_stop": "Остановить новые рейсы",
			"cancel_buy_remainder": "Отменить свободный остаток закупки", "sale_one": "Продать 1 единицу", "sale_all": "Продать доступный объём",
			"sign_support": "Подписать поддержку после передачи", "refresh_version": "Показать последнюю версию"
		}
		show_notice(labels.get(action, "Действие выбрано"), "Это визуальный прототип с примером данных.\nВыбрано: " + labels.get(action, action) + ".\n\nВ игре команда проходит проверку прав, ресурсов и присутствия. Здесь деньги и товары не меняются.")
	refresh_state()
	ui_action.emit(StringName(action), {"screen": current_key, "wage_minor": wage_minor, "production_enabled": producing})

func show_notice(title: String, content: String) -> void:
	last_notice = title
	if is_instance_valid(overlay): overlay.free()
	overlay = Control.new()
	add_child(overlay)
	overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var shade := ColorRect.new()
	shade.color = Color(0.06,0.13,0.10,0.72)
	overlay.add_child(shade)
	shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var frame := Panel.new()
	frame.position = Vector2(280,190)
	frame.size = Vector2(880,644)
	frame.theme = load("res://theme.tres")
	var style := StyleBoxFlat.new()
	style.bg_color = Color("#F7F3E9")
	style.set_corner_radius_all(24)
	frame.add_theme_stylebox_override("panel",style)
	overlay.add_child(frame)
	var heading := Label.new()
	heading.position = Vector2(28,24)
	heading.size = Vector2(760,68)
	heading.text = title
	heading.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	heading.add_theme_font_size_override("font_size",28)
	heading.add_theme_font_override("font",load("res://assets/fonts/Nunito-ExtraBold.ttf"))
	frame.add_child(heading)
	var scroll := ScrollContainer.new()
	scroll.position = Vector2(28,118)
	scroll.size = Vector2(824,410)
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	frame.add_child(scroll)
	var body := Label.new()
	body.text = content
	body.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	body.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	body.add_theme_font_size_override("font_size",22)
	scroll.add_child(body)
	var close := Button.new()
	close.position = Vector2(28,558)
	close.size = Vector2(824,54)
	close.text = "Понятно"
	close.add_theme_color_override("font_color",Color("#253F36"))
	var bs := StyleBoxFlat.new()
	bs.bg_color = Color("#E3EDDA")
	bs.set_corner_radius_all(14)
	close.add_theme_stylebox_override("normal",bs)
	close.pressed.connect(func(): overlay.queue_free())
	frame.add_child(close)

func _unhandled_key_input(event: InputEvent) -> void:
	if event.is_action_pressed("ui_cancel"):
		if is_instance_valid(overlay): overlay.queue_free()
		else: act("back")
