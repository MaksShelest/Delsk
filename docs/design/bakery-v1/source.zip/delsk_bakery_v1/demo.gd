extends Node
## Presentation fixture only. The reusable BakeryTablet scene has no script.
## This signal is the boundary for a real C# presenter / command adapter.
signal ui_action(action: StringName, payload: Dictionary)

@onready var tablet: Control = $Tablet
@onready var panel: Control = $Tablet/Panel
var production_on := true
var time_running := false
var wage_minor := 20
var logistics_wage_minor := 20
var overlay: Control
var modal_body: VBoxContainer
var menu_source := true

func _ready() -> void:
	btn("Production/PauseProduction").pressed.connect(toggle_production)
	btn("Workers/WageMinus").pressed.connect(change_wage.bind(-5))
	btn("Workers/WagePlus").pressed.connect(change_wage.bind(5))
	btn("TimeToggle").pressed.connect(toggle_time)
	btn("Help").pressed.connect(show_help)
	btn("Close").pressed.connect(close_tablet)
	btn("Delivery/DeliverySettings").pressed.connect(show_delivery)
	btn("Delivery/NoTransport/BuyTransport").pressed.connect(show_purchase)
	btn("Delivery/Source").pressed.connect(show_routes.bind(true))
	btn("Delivery/Destination").pressed.connect(show_routes.bind(false))
	btn("Stock/Deposit").pressed.connect(show_transfer.bind(true))
	btn("Stock/Withdraw").pressed.connect(show_transfer.bind(false))
	btn("Upgrade/UpgradeProduction").pressed.connect(show_upgrade)
	btn("Delivery/SupplyToggle").toggled.connect(func(on: bool): ui_action.emit(&"set_inbound_enabled", {"enabled": on}))
	btn("Delivery/SendToggle").toggled.connect(func(on: bool): ui_action.emit(&"set_outbound_enabled", {"enabled": on}))
	var capture := ""
	var view := ""
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--capture="): capture = arg.trim_prefix("--capture=")
		if arg.begins_with("--view="): view = arg.trim_prefix("--view=")
	if view == "delivery": show_delivery()
	if view == "routes": show_routes(false)
	if view == "paused": toggle_production()
	if view == "no_transport": show_no_transport()
	if not capture.is_empty():
		for frame in range(8): await get_tree().process_frame
		await RenderingServer.frame_post_draw
		var err := get_viewport().get_texture().get_image().save_png(capture)
		print("CAPTURE_RESULT=", err, " ", capture)
		get_tree().quit(err)

func btn(path: String) -> Button:
	return panel.get_node(path) as Button

func toggle_production() -> void:
	production_on = not production_on
	btn("Production/PauseProduction").text = "Приостановить" if production_on else "Запустить"
	panel.get_node("StatusPill/Text").text = "Работает" if production_on else "Остановлена"
	ui_action.emit(&"set_production_enabled", {"enabled": production_on})

func change_wage(delta: int) -> void:
	wage_minor = maxi(0, wage_minor + delta)
	panel.get_node("Workers/WageAmount").text = money(wage_minor)
	ui_action.emit(&"request_production_wage", {"minor_units": wage_minor})

func toggle_time() -> void:
	time_running = not time_running
	panel.get_node("PauseState").text = "Время идёт" if time_running else "Время остановлено"
	btn("TimeToggle").text = "Остановить время" if time_running else "Продолжить время"
	ui_action.emit(&"set_tablet_pause", {"paused": not time_running})

func close_tablet() -> void:
	tablet.hide()
	ui_action.emit(&"close_tablet", {})

func _unhandled_key_input(event: InputEvent) -> void:
	if event.is_action_pressed("ui_cancel"):
		if is_instance_valid(overlay): overlay.queue_free()
		else: tablet.visible = not tablet.visible

func money(minor: int) -> String:
	return ("%.2f" % (minor / 100.0)).replace(".", ",")

func box_style(bg: String, radius: int = 22) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = Color(bg)
	s.set_corner_radius_all(radius)
	s.content_margin_left = 28
	s.content_margin_right = 28
	s.content_margin_top = 24
	s.content_margin_bottom = 24
	return s

func open_modal(title: String, subtitle: String = "") -> void:
	if is_instance_valid(overlay): overlay.free()
	overlay = Control.new()
	overlay.name = "Modal"
	tablet.add_child(overlay)
	overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var shade := ColorRect.new()
	shade.color = Color(0.06, 0.13, 0.10, 0.66)
	overlay.add_child(shade)
	shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var center := CenterContainer.new()
	overlay.add_child(center)
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	center.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var frame := PanelContainer.new()
	frame.custom_minimum_size.x = 570
	frame.add_theme_stylebox_override("panel", box_style("#F7F3E9"))
	center.add_child(frame)
	modal_body = VBoxContainer.new()
	modal_body.add_theme_constant_override("separation", 16)
	frame.add_child(modal_body)
	var header := HBoxContainer.new()
	modal_body.add_child(header)
	var heading := text_label(title, 28, true)
	heading.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	header.add_child(heading)
	var close := make_button("×", func(): overlay.queue_free())
	close.custom_minimum_size = Vector2(44,44)
	header.add_child(close)
	if not subtitle.is_empty(): add_text(subtitle, 18, "#778277")

func text_label(text: String, size: int = 20, bold: bool = false) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", Color("#253F36"))
	if bold: l.add_theme_font_override("font", load("res://delsk_bakery_ui/assets/fonts/Nunito-ExtraBold.ttf"))
	return l

func add_text(text: String, size: int = 20, tint: String = "#253F36") -> Label:
	var l := text_label(text, size)
	l.add_theme_color_override("font_color", Color(tint))
	modal_body.add_child(l)
	return l

func make_button(text: String, callback: Callable) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size.y = 50
	for item in [["normal", "#E6EBD9"], ["hover", "#D7E3CB"], ["pressed", "#C9DBC0"]]:
		var style := box_style(item[1],14)
		style.content_margin_left = 18
		style.content_margin_right = 18
		style.content_margin_top = 10
		style.content_margin_bottom = 10
		b.add_theme_stylebox_override(item[0], style)
	b.add_theme_color_override("font_color", Color("#255D44"))
	b.add_theme_color_override("font_hover_color", Color("#255D44"))
	b.add_theme_color_override("font_pressed_color", Color("#255D44"))
	b.pressed.connect(callback)
	return b

func add_button(text: String, callback: Callable) -> Button:
	var b := make_button(text, callback)
	modal_body.add_child(b)
	return b

func show_delivery() -> void:
	open_modal("Мой грузовик", "Доставка пекарни · уровень 1")
	add_stat("Груз за рейс", "10 ед.")
	add_stat("Команда", "2 / 2")
	add_text("Зарплата за работника / с", 18, "#778277")
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 14)
	modal_body.add_child(row)
	var amount := text_label(money(logistics_wage_minor), 28, true)
	amount.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	amount.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	row.add_child(make_button("−", func():
		logistics_wage_minor = maxi(0, logistics_wage_minor - 5)
		amount.text = money(logistics_wage_minor)
		ui_action.emit(&"request_logistics_wage", {"minor_units": logistics_wage_minor})))
	row.add_child(amount)
	row.add_child(make_button("+", func():
		logistics_wage_minor += 5
		amount.text = money(logistics_wage_minor)
		ui_action.emit(&"request_logistics_wage", {"minor_units": logistics_wage_minor})))
	add_text("При простое зарплата не списывается.\nУже выехавший грузовик завершит рейс.", 18, "#778277")
	add_button("Улучшить · 300 монет + 10 досок", func():
		show_delivery_upgrade())

func add_stat(title: String, value: String) -> void:
	var row := HBoxContainer.new()
	modal_body.add_child(row)
	var title_label := text_label(title, 22)
	title_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(title_label)
	row.add_child(text_label(value, 22, true))

func show_delivery_upgrade() -> void:
	open_modal("Больше груза за рейс")
	add_text("Уровень 2 · груз 20 ед. · команда до 3 человек",20)
	add_text("Нужно: 300 монет и 10 досок на пекарне",18,"#778277")
	add_button("Улучшить грузовик", func():
		ui_action.emit(&"upgrade_delivery", {})
		overlay.queue_free())

func show_routes(source: bool) -> void:
	menu_source = source
	open_modal("Откуда привозить зерно?" if source else "Куда отправлять хлеб?")
	if source:
		add_button("Склад №1 · 80 ед. зерна", choose_route.bind("Склад №1"))
	else:
		add_button("Моя лавочка", choose_route.bind("Моя лавочка"))
		add_button("Склад №1", choose_route.bind("Склад №1"))
		add_button("Столица · осталось 20 буханок", choose_route.bind("Столица · осталось 20"))
		add_button("Анна · осталось 8 буханок", choose_route.bind("Анна · осталось 8"))
		add_text("Объём по договору подставляется автоматически",17,"#778277")

func choose_route(value: String) -> void:
	btn("Delivery/Source" if menu_source else "Delivery/Destination").text = value + " → Пекарня" if menu_source else value
	ui_action.emit(&"select_inbound_source" if menu_source else &"select_outbound_destination", {"fixture_label": value})
	overlay.queue_free()

func show_transfer(inbound: bool) -> void:
	open_modal("Пополнить запас зерна" if inbound else "Забрать хлеб")
	add_text("Из рюкзака → в пекарню" if inbound else "Из пекарни → в рюкзак",20)
	add_text("Передача доступна рядом с пекарней",18,"#778277")
	add_button("Передать 1 ед. зерна" if inbound else "Забрать 1 буханку", func():
		ui_action.emit(&"deposit_one" if inbound else &"withdraw_one", {})
		overlay.queue_free())

func show_upgrade() -> void:
	open_modal("Улучшить пекарню?")
	add_text("Уровень 2 · 4 рабочих места",23)
	add_text("Вдвое быстрее при полной команде.\nНовые работники приходят постепенно.",19,"#778277")
	add_text("Стоимость: 200 монет + 10 досок",22)
	add_text("Доски должны находиться в запасе пекарни",17,"#778277")
	add_button("Улучшить", func():
		ui_action.emit(&"upgrade_production", {})
		overlay.queue_free())

func show_help() -> void:
	open_modal("Пекарня — это просто")
	add_text("1. Привези зерно.")
	add_text("2. Назначь зарплату и дождись работников.")
	add_text("3. Забери хлеб или включи доставку.")
	add_text("Производство, подвоз и отправка\nвключаются по отдельности.",19,"#778277")
	add_text("На паузе можно спокойно выбрать настройки.",18,"#778277")

func show_no_transport() -> void:
	for key in ["DeliverySettings", "SupplyTitle", "SupplyToggle", "Source", "RouteTruck", "TripStatus", "Divider2", "SendTitle", "SendToggle", "Destination"]:
		panel.get_node("Delivery/" + key).hide()
	panel.get_node("Delivery/CrewBrief").text = "Пока переносим ресурсы вручную"
	panel.get_node("Delivery/NoTransport").show()

func show_purchase() -> void:
	open_modal("Грузовик для пекарни")
	add_text("10 единиц груза за рейс · 2 рабочих места",20)
	add_text("Найм потребует времени и зарплаты.",19,"#778277")
	add_button("Купить за 200 монет",func():
		ui_action.emit(&"purchase_delivery", {})
		overlay.queue_free())
